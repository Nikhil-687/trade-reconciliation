# trade-reconciliation

A daily automated trade reconciliation utility that logs every run and maintains historical records.

## 📦 Install

```bash
sudo dpkg -i traderecon_1.0.deb
```

visit to the project and do 

```bash
chmod +x ./run.sh [OPTION]
```
[OPTION] : "--summary-only", "--json-output", "--csv-output"
